"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Turnstile from "react-turnstile";
import { useTranslations, useLocale } from "next-intl";
import { motion, AnimatePresence } from "framer-motion";
import {
  trackPartnerPageView,
  trackPartnerStepEntered,
  trackPartnerStepBack,
  trackPartnerTypeSelected,
  trackPartnerPlanSelected,
  trackPartnerApplicationSubmitted,
  trackPartnerApplicationError,
} from "@/lib/analytics/gtag";

// =========================================================
// Wizard step-by-step, stesso linguaggio visivo e stessa
// meccanica di src/app/craft-your-experience/page.tsx (header
// con back/progress/counter, slide animation, footer back/next) —
// niente pagina "vetrina" con piani/FAQ, solo le domande. Le
// domande dello step "details" cambiano in base al tipo di
// operatore scelto allo step "type" (vedi DETAIL_FIELDS).
// =========================================================

const STEP_IDS = ["type", "basics", "details", "plan", "message"] as const;
type StepId = (typeof STEP_IDS)[number];

type Category =
  | "hotel"
  | "restaurant"
  | "private_charter"
  | "tour_operator"
  | "other";

const CATEGORY_VALUES: Category[] = [
  "hotel",
  "restaurant",
  "private_charter",
  "tour_operator",
  "other",
];

// Valori snake_case (DB/API) -> segmento camelCase usato nelle chiavi
// di traduzione in en.json (steps.type.privateCharter, ecc.).
const CATEGORY_I18N_KEY: Record<Category, string> = {
  hotel: "hotel",
  restaurant: "restaurant",
  private_charter: "privateCharter",
  tour_operator: "tourOperator",
  other: "other",
};

interface DetailField {
  key: string;
  type: "text" | "select" | "textarea";
  optionsKey?: string;
}

const DETAIL_FIELDS: Record<Category, DetailField[]> = {
  hotel: [
    { key: "roomsCount", type: "select", optionsKey: "roomsOptions" },
    { key: "category", type: "select", optionsKey: "categoryOptions" },
    { key: "area", type: "text" },
  ],
  restaurant: [
    { key: "cuisineType", type: "text" },
    { key: "seatingCapacity", type: "select", optionsKey: "seatingOptions" },
    { key: "priceRange", type: "select", optionsKey: "priceOptions" },
  ],
  private_charter: [
    { key: "fleetType", type: "text" },
    { key: "maxGuests", type: "select", optionsKey: "maxGuestsOptions" },
    { key: "skipperIncluded", type: "select", optionsKey: "skipperOptions" },
  ],
  tour_operator: [
    { key: "tourTypes", type: "text" },
    { key: "groupSize", type: "select", optionsKey: "groupSizeOptions" },
    { key: "languages", type: "text" },
  ],
  other: [{ key: "description", type: "textarea" }],
};

const PLAN_VALUES = ["base", "premium", "signature", "not_sure"] as const;
type PlanKey = (typeof PLAN_VALUES)[number];

const slideVariants = {
  enter: (direction: number) => ({
    x: direction > 0 ? 80 : -80,
    opacity: 0,
  }),
  center: {
    x: 0,
    opacity: 1,
  },
  exit: (direction: number) => ({
    x: direction > 0 ? -80 : 80,
    opacity: 0,
  }),
};

// Legge un oggetto "pseudo-array" (chiavi numeriche "0","1","2"...)
// da site_copy — stesso schema di proposal.introTitles, qui iterato
// per intero invece che pescato per indice.
function rawList(raw: unknown): string[] {
  if (!raw || typeof raw !== "object") return [];
  return Object.values(raw as Record<string, string>);
}

const inputClass =
  "w-full rounded-2xl px-6 py-3.5 text-white placeholder:text-zinc-500 outline-none border border-white/10 bg-white/5 focus:border-white/40 transition";

export default function BecomePartnerClient() {
  const t = useTranslations("becomePartner");
  const locale = useLocale();
  const router = useRouter();

  const [currentStep, setCurrentStep] = useState(0);
  const [direction, setDirection] = useState(0);

  const [category, setCategory] = useState<Category | null>(null);
  const [companyName, setCompanyName] = useState("");
  const [contactName, setContactName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [website, setWebsite] = useState("");
  const [instagram, setInstagram] = useState("");
  const [details, setDetails] = useState<Record<string, string>>({});
  const [planInterest, setPlanInterest] = useState<PlanKey>("not_sure");
  const [message, setMessage] = useState("");
  const [captchaToken, setCaptchaToken] = useState("");
  const [status, setStatus] = useState<"idle" | "sending" | "success" | "error">("idle");

  const stepId: StepId = STEP_IDS[currentStep];
  const totalSteps = STEP_IDS.length;
  const progressPercent = ((currentStep + 1) / totalSteps) * 100;

  useEffect(() => {
    trackPartnerPageView();
  }, []);

  useEffect(() => {
    trackPartnerStepEntered(stepId, currentStep);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentStep]);

  function setDetailField(key: string, value: string) {
    setDetails((prev) => ({ ...prev, [key]: value }));
  }

  function isStepValid(step: StepId): boolean {
    switch (step) {
      case "type":
        return category !== null;
      case "basics":
        return (
          !!companyName.trim() &&
          !!contactName.trim() &&
          /\S+@\S+\.\S+/.test(email)
        );
      case "details": {
        if (!category) return false;
        return DETAIL_FIELDS[category].every((f) => !!details[f.key]?.trim());
      }
      case "plan":
        return true;
      case "message":
        return !!captchaToken;
      default:
        return true;
    }
  }

  const currentStepValid = isStepValid(stepId);

  function goNext() {
    if (!currentStepValid) return;

    if (stepId === "message") {
      handleSubmit();
      return;
    }

    setDirection(1);
    setCurrentStep((s) => s + 1);
  }

  function goBack() {
    if (currentStep === 0) {
      router.push("/");
      return;
    }
    trackPartnerStepBack(stepId, currentStep);
    setDirection(-1);
    setCurrentStep((s) => s - 1);
  }

  async function handleSubmit() {
    if (!category) return;

    setStatus("sending");

    try {

      const response = await fetch("/api/partner-application", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          turnstileToken: captchaToken,
          companyName,
          contactName,
          email,
          phone,
          category,
          details,
          planInterest,
          website,
          instagram,
          message,
          locale,
        }),
      });

      const data = await response.json();

      if (!data.success) {
        setStatus("error");
        trackPartnerApplicationError(data.error || "unknown");
        return;
      }

      setStatus("success");
      trackPartnerApplicationSubmitted(planInterest, category);

    } catch (err) {
      console.error("partner-application submit failed:", err);
      setStatus("error");
      trackPartnerApplicationError("network");
    }
  }

  function selectCategory(value: Category) {
    setCategory(value);
    setDetails({});
    trackPartnerTypeSelected(value);
  }

  function selectPlan(plan: PlanKey) {
    setPlanInterest(plan);
    if (plan !== "not_sure") trackPartnerPlanSelected(plan);
  }

  // =======================================================
  // SUCCESS
  // =======================================================

  if (status === "success") {
    return (
      <main className="h-dvh flex items-center justify-center bg-[#0C0C0C] text-white px-6 text-center">
        <p className="text-xl md:text-2xl font-light max-w-md leading-relaxed">
          {t("success")}
        </p>
      </main>
    );
  }

  // =======================================================
  // STEP CONTENT
  // =======================================================

  function renderStep() {
    switch (stepId) {

      case "type":
        return (
          <div className="grid gap-3">
            {CATEGORY_VALUES.map((value) => (
              <button
                type="button"
                key={value}
                onClick={() => selectCategory(value)}
                className={`border rounded-2xl px-6 py-5 text-left transition-all duration-500 ease-out ${
                  category === value
                    ? "border-white bg-white text-black"
                    : "border-white/10 bg-white/5 hover:border-white/40"
                }`}
              >
                <span className="block text-base font-light">
                  {t(`steps.type.${CATEGORY_I18N_KEY[value]}`)}
                </span>
              </button>
            ))}
          </div>
        );

      case "basics":
        return (
          <div className="space-y-5">
            <TextField
              label={t("steps.basics.companyName")}
              value={companyName}
              onChange={setCompanyName}
            />
            <TextField
              label={t("steps.basics.contactName")}
              value={contactName}
              onChange={setContactName}
            />
            <TextField
              label={t("steps.basics.email")}
              value={email}
              onChange={setEmail}
              type="email"
            />
            <TextField
              label={t("steps.basics.phone")}
              value={phone}
              onChange={setPhone}
              type="tel"
            />
            <TextField
              label={t("steps.basics.website")}
              value={website}
              onChange={setWebsite}
              type="url"
            />
            <TextField
              label={t("steps.basics.instagram")}
              value={instagram}
              onChange={setInstagram}
            />
          </div>
        );

      case "details": {
        if (!category) return null;

        const i18nKey = CATEGORY_I18N_KEY[category];
        const fields = DETAIL_FIELDS[category];

        return (
          <div className="space-y-5">
            {fields.map((field) => {

              const label = t(`steps.details.${i18nKey}.${field.key}`);

              if (field.type === "text") {
                return (
                  <TextField
                    key={field.key}
                    label={label}
                    value={details[field.key] || ""}
                    onChange={(v) => setDetailField(field.key, v)}
                  />
                );
              }

              if (field.type === "textarea") {
                return (
                  <div key={field.key}>
                    <p className="uppercase tracking-[0.3em] text-zinc-500 text-sm mb-2">
                      {label}
                    </p>
                    <textarea
                      value={details[field.key] || ""}
                      onChange={(e) => setDetailField(field.key, e.target.value)}
                      rows={4}
                      className={inputClass}
                    />
                  </div>
                );
              }

              const options = rawList(
                t.raw(`steps.details.${i18nKey}.${field.optionsKey}`)
              );

              return (
                <div key={field.key}>
                  <p className="uppercase tracking-[0.3em] text-zinc-500 text-sm mb-2">
                    {label}
                  </p>
                  <div className="grid gap-2.5">
                    {options.map((option) => (
                      <button
                        type="button"
                        key={option}
                        onClick={() => setDetailField(field.key, option)}
                        className={`border rounded-2xl px-5 py-3 text-left text-sm transition-all duration-500 ease-out ${
                          details[field.key] === option
                            ? "border-white bg-white text-black"
                            : "border-white/10 bg-white/5 hover:border-white/40"
                        }`}
                      >
                        {option}
                      </button>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        );
      }

      case "plan":
        return (
          <div className="grid gap-3">
            {PLAN_VALUES.map((plan) => (
              <button
                type="button"
                key={plan}
                onClick={() => selectPlan(plan)}
                className={`min-w-0 border rounded-2xl px-6 py-5 text-left transition-all duration-500 ease-out ${
                  planInterest === plan
                    ? "border-white bg-white text-black"
                    : "border-white/10 bg-white/5 hover:border-white/40"
                }`}
              >
                {plan === "not_sure" ? (
                  <span className="block text-base font-light break-words">
                    {t("steps.plan.notSure")}
                  </span>
                ) : (
                  <>
                    <div className="flex items-baseline justify-between gap-2 flex-wrap">
                      <span className="min-w-0 break-words text-base font-light">
                        {t(`steps.plan.${plan}.name`)}
                      </span>
                      <span
                        className={`min-w-0 break-words text-sm ${
                          planInterest === plan ? "text-black/60" : "text-zinc-500"
                        }`}
                      >
                        {t(`steps.plan.${plan}.price`)}
                      </span>
                    </div>
                    <span
                      className={`block text-sm mt-1 ${
                        planInterest === plan ? "text-black/60" : "text-zinc-500"
                      }`}
                    >
                      {t(`steps.plan.${plan}.tagline`)}
                    </span>
                  </>
                )}
              </button>
            ))}
          </div>
        );

      case "message":
        return (
          <div className="space-y-6">
            <textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder={t("steps.message.placeholder")}
              rows={5}
              className={inputClass}
            />

            <div className="flex justify-center">
              <Turnstile
                sitekey={process.env.NEXT_PUBLIC_TURNSTILE_SITE_KEY!}
                onVerify={(token) => setCaptchaToken(token)}
              />
            </div>

            {status === "error" && (
              <p className="text-center text-red-400 text-sm">{t("error")}</p>
            )}
          </div>
        );

      default:
        return null;
    }
  }

  // =======================================================
  // SHELL
  // =======================================================

  return (
    <main className="h-dvh overflow-hidden bg-[#0C0C0C] text-white flex flex-col break-words">

      {/* HEADER: back + progress + counter — compatto, altezza fissa */}
      <div className="px-6 pt-4 pb-2 md:pt-6 md:pb-3 max-w-xl w-full mx-auto shrink-0">

        <div className="flex items-center gap-4 mb-2 md:mb-4">

          <button
            type="button"
            onClick={goBack}
            aria-label="Back"
            className="text-2xl opacity-70 hover:opacity-100 transition-opacity"
          >
            &#8592;
          </button>

          <div className="flex-1 h-[2px] bg-white/10 rounded-full overflow-hidden">
            <div
              className="h-full bg-[#d6c6a5] transition-all duration-500 ease-out"
              style={{ width: `${progressPercent}%` }}
            />
          </div>

          <p className="text-xs text-zinc-500 tabular-nums">
            {currentStep + 1} / {totalSteps}
          </p>

        </div>

        <p className="uppercase tracking-[0.3em] text-zinc-500 text-xs mb-2">
          {t("hero.eyebrow")}
        </p>

        <h1 className="text-xl md:text-4xl font-light leading-tight">
          {t(`steps.${stepId}.title`)}
        </h1>

      </div>

      <div className="flex-1 min-h-0 flex flex-col justify-between gap-3 md:gap-6 overflow-y-auto pt-4 pb-4 md:pb-6 px-6 max-w-xl w-full mx-auto">

        <AnimatePresence mode="wait" custom={direction}>
          <motion.div
            key={currentStep}
            custom={direction}
            variants={slideVariants}
            initial="enter"
            animate="center"
            exit="exit"
            transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
          >
            {renderStep()}
          </motion.div>
        </AnimatePresence>

        <div className="flex gap-4 shrink-0">

          <button
            type="button"
            onClick={goBack}
            className="w-1/3 rounded-full px-2 py-3.5 uppercase tracking-[0.25em] text-xs border border-white/20 text-white/70 hover:border-white/40 hover:text-white transition-all duration-500"
          >
            {t("nav.back")}
          </button>

          <button
            type="button"
            onClick={goNext}
            disabled={!currentStepValid || status === "sending"}
            className={`w-2/3 rounded-full px-4 py-3.5 uppercase tracking-[0.2em] text-[11px] leading-snug text-center transition-all duration-500 ${
              currentStepValid && status !== "sending"
                ? "bg-white text-black hover:scale-[1.02]"
                : "bg-white/10 text-white/30 cursor-not-allowed"
            }`}
          >
            {stepId === "message"
              ? status === "sending"
                ? t("nav.submitting")
                : t("nav.submit")
              : t("nav.next")}
          </button>

        </div>
      </div>
    </main>
  );
}

function TextField({
  label,
  value,
  onChange,
  type = "text",
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  type?: string;
}) {
  return (
    <div>
      <p className="uppercase tracking-[0.3em] text-zinc-500 text-sm mb-2">
        {label}
      </p>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className={inputClass}
      />
    </div>
  );
}
