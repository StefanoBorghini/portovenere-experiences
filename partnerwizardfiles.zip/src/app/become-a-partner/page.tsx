import type { Metadata } from "next";
import BecomePartnerClient from "./BecomePartnerClient";

export const metadata: Metadata = {
  title: "Become a Partner — Portovenere Experience",
  description:
    "Join the Portovenere Experience ecosystem — qualified visibility and real client opportunities for hotels, restaurants, experience providers and travel professionals.",
};

export default function BecomePartnerPage() {
  return <BecomePartnerClient />;
}
