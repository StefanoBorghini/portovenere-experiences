import { NextRequest, NextResponse } from "next/server";
import { getSupabaseAdmin } from "@/lib/supabase/adminClient";
import { sendEmail } from "@/lib/email/sendEmail";
import { ownerNewPartnerApplicationTemplate } from "@/lib/email/templates";

// =========================================================
// POST /api/partner-application
// Wizard step-by-step su /become-a-partner. Nessuna policy
// pubblica di insert su partner_applications (vedi migration) —
// l'unica scrittura passa da qui, lato server, con la service
// role key, dopo verifica Turnstile — stesso schema di
// request-booking.
// =========================================================

const VALID_CATEGORIES = [
  "hotel",
  "restaurant",
  "private_charter",
  "tour_operator",
  "other",
];

const VALID_PLANS = ["base", "premium", "signature", "not_sure"];

export async function POST(req: NextRequest) {

  try {

    const body = await req.json();

    const {
      turnstileToken,
      companyName,
      contactName,
      email,
      phone,
      category,
      details,
      planInterest,
      website,
      instagram,
      message,
      locale,
    } = body;

    if (!turnstileToken) {
      return NextResponse.json(
        { success: false, error: "Missing captcha token" },
        { status: 400 }
      );
    }

    const verifyResponse = await fetch(
      "https://challenges.cloudflare.com/turnstile/v0/siteverify",
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          secret: process.env.TURNSTILE_SECRET_KEY,
          response: turnstileToken,
        }),
      }
    );

    const verifyData = await verifyResponse.json();

    if (!verifyData.success) {
      return NextResponse.json(
        { success: false, error: "Captcha verification failed" },
        { status: 400 }
      );
    }

    if (
      !companyName ||
      !contactName ||
      !email ||
      !VALID_CATEGORIES.includes(category)
    ) {
      return NextResponse.json(
        { success: false, error: "Missing required fields" },
        { status: 400 }
      );
    }

    const cleanPlan = VALID_PLANS.includes(planInterest)
      ? planInterest
      : "not_sure";

    const cleanDetails =
      details && typeof details === "object" && !Array.isArray(details)
        ? details
        : {};

    const supabaseAdmin = getSupabaseAdmin();

    const { error: insertError } = await supabaseAdmin
      .from("partner_applications")
      .insert([
        {
          company_name: companyName,
          contact_name: contactName,
          email,
          phone: phone || null,
          category,
          details: cleanDetails,
          plan_interest: cleanPlan,
          website: website || null,
          instagram: instagram || null,
          message: message || null,
          locale: locale || null,
        },
      ]);

    if (insertError) {
      console.error("partner-application insert error:", insertError);
      return NextResponse.json(
        { success: false, error: "Could not save application" },
        { status: 500 }
      );
    }

    const ownerEmail =
      process.env.OWNER_NOTIFICATION_EMAIL || "info@portovenere.com";

    const emailResult = await sendEmail({
      to: ownerEmail,
      subject: `New partner application — ${companyName}`,
      html: ownerNewPartnerApplicationTemplate({
        companyName,
        contactName,
        email,
        phone,
        category,
        details: cleanDetails,
        planInterest: cleanPlan,
        website,
        instagram,
        message,
      }),
    });

    if (!emailResult.success) {
      console.error("partner-application notification email failed:", emailResult.error);
    }

    return NextResponse.json({ success: true });

  } catch (err) {

    console.error("partner-application error:", err);

    return NextResponse.json(
      { success: false, error: "Unexpected error" },
      { status: 500 }
    );
  }
}
