"use client";

import { useState } from "react";
import Link from "next/link";
import { useTranslations } from "next-intl";
import { AnimatePresence, motion } from "framer-motion";

// =========================================================
// Nav condivisa tra le pagine pubbliche (home, /become-a-partner,
// e future pagine editoriali) — non usata su /start (deliberatamente
// senza menu, vedi StartClient.tsx) ne' sul configuratore (flusso
// a step, una distrazione in meno). "How It Works" punta alla
// sezione reale gia' esistente in home (id="how-it-works"), "Contact"
// allo stesso canale WhatsApp usato ovunque nel sito — nessuna pagina
// contatti dedicata esiste ancora.
// =========================================================

const CONTACT_WHATSAPP_URL = "https://wa.me/393487140722";

export default function PublicHeader() {
  const t = useTranslations("nav");
  const [open, setOpen] = useState(false);

  const links = [
    { label: t("home"), href: "/" },
    { label: t("configurator"), href: "/craft-your-experience" },
    { label: t("howItWorks"), href: "/#how-it-works" },
    { label: t("partners"), href: "/become-a-partner" },
  ];

  return (
    <header className="relative z-50">
      <div className="max-w-7xl mx-auto flex items-center justify-between px-6 py-4 md:py-6">
        <Link
          href="/"
          aria-label="Portovenere Experiences — home"
          onClick={() => setOpen(false)}
        >
          <img
            src="/logo-white.png"
            alt="Portovenere Experiences"
            className="w-auto h-9 md:h-12"
          />
        </Link>

        {/* DESKTOP */}
        <nav className="hidden md:flex items-center gap-8">
          {links.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className="text-[11px] uppercase tracking-[0.2em] text-zinc-300 hover:text-white transition-colors duration-300"
            >
              {link.label}
            </Link>
          ))}
          <a
            href={CONTACT_WHATSAPP_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="text-[11px] uppercase tracking-[0.2em] border border-white/20 rounded-full px-5 py-2.5 hover:bg-white hover:text-black transition-all duration-300"
          >
            {t("contact")}
          </a>
        </nav>

        {/* MOBILE TOGGLE */}
        <button
          type="button"
          onClick={() => setOpen((v) => !v)}
          aria-expanded={open}
          aria-controls="public-nav-mobile-panel"
          aria-label={open ? "Close menu" : "Open menu"}
          className="md:hidden relative z-50 w-9 h-9 flex flex-col items-center justify-center gap-[5px] focus-visible:outline focus-visible:outline-1 focus-visible:outline-white/60 focus-visible:outline-offset-2 rounded-full"
        >
          <span
            className={`block h-px w-5 bg-white transition-transform duration-300 ${
              open ? "translate-y-[3px] rotate-45" : ""
            }`}
          />
          <span
            className={`block h-px w-5 bg-white transition-transform duration-300 ${
              open ? "-translate-y-[3px] -rotate-45" : ""
            }`}
          />
        </button>
      </div>

      {/* MOBILE PANEL */}
      <AnimatePresence>
        {open && (
          <motion.div
            id="public-nav-mobile-panel"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
            className="md:hidden overflow-hidden bg-[#0C0C0C] border-t border-b border-[#EDEBE7]/10"
          >
            <nav className="flex flex-col px-6 py-6 gap-5">
              {links.map((link) => (
                <Link
                  key={link.href}
                  href={link.href}
                  onClick={() => setOpen(false)}
                  className="text-sm uppercase tracking-[0.2em] text-zinc-200"
                >
                  {link.label}
                </Link>
              ))}
              <a
                href={CONTACT_WHATSAPP_URL}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => setOpen(false)}
                className="text-sm uppercase tracking-[0.2em] text-zinc-200"
              >
                {t("contact")}
              </a>
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
