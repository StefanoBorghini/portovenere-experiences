-- =====================================================================
-- partner_applications
-- =====================================================================
-- Candidature ricevute dal wizard step-by-step su /become-a-partner
-- (hotel, ristoranti, noleggio privato, tour operator, altro) che
-- vogliono entrare nell'ecosistema Portovenere Experience.
--
-- Nessuna scrittura pubblica via RLS: l'unico punto di inserimento e'
-- /api/partner-application, che gira lato server con la service role
-- key (bypassa RLS) dopo aver verificato Turnstile — stessa cautela
-- gia' usata per site_copy_translations, per non esporre un endpoint
-- di scrittura pubblica diretta sulla tabella.
--
-- Da eseguire UNA VOLTA nel SQL editor di Supabase.
-- =====================================================================

create table if not exists partner_applications (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),

  company_name text not null,
  contact_name text not null,
  email text not null,
  phone text,

  -- Un solo tipo primario per candidatura — il wizard si ramifica su
  -- questo (step "details" mostra domande diverse a seconda del
  -- valore). 'hotel' | 'restaurant' | 'private_charter' |
  -- 'tour_operator' | 'other'.
  category text not null,

  -- Risposte dello step "details", specifiche per categoria (es.
  -- {"roomsCount": "11–30", "area": "Le Grazie"} per un hotel).
  -- jsonb invece di colonne rigide per categoria: lo shape cambia
  -- per tipo di operatore e potrebbe evolvere senza richiedere
  -- nuove migration ogni volta.
  details jsonb not null default '{}',

  -- 'base' | 'premium' | 'signature' | 'not_sure'
  plan_interest text not null default 'not_sure',

  website text,
  instagram text,
  message text,

  -- Triage lato admin — nessun pannello dedicato ancora, ma il campo
  -- e' pronto per quando servira' (stesso schema di leads/Proposal).
  status text not null default 'new'
    check (status in ('new', 'contacted', 'approved', 'rejected')),

  locale text
);

alter table partner_applications enable row level security;

-- Nessuna policy per anon/authenticated: RLS attiva senza eccezioni
-- blocca sia lettura che scrittura dal client pubblico. L'unico
-- accesso e' server-side con la service role key, che bypassa RLS
-- comunque (vedi src/lib/supabase/adminClient.ts).
