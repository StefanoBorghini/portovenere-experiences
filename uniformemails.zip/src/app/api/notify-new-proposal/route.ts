import { NextRequest, NextResponse } from "next/server";
import { supabase } from "@/lib/supabase";
import { sendEmail } from "@/lib/email/sendEmail";
import { ownerNewProposalTemplate, proposalGeneratedTemplate } from "@/lib/email/templates";
import { getAvailableLineItemsForLead } from "@/lib/proposal-engine/getFeaturedExperienceForLead";

// =========================================================
// POST /api/notify-new-proposal
// Chiamata subito dopo l'insert della Proposal in
// craft-your-experience/page.tsx — indipendente dal fatto
// che il cliente richieda o no il booking privato.
//
// Il client manda solo lo slug: tutti i dati veri (nome,
// email, esperienze, ecc.) vengono recuperati dal DB, non
// dal body della richiesta. Senza questo controllo, chiunque
// potrebbe chiamare questa route direttamente con dati finti
// e spammare la tua inbox con "nuove proposal" inventate.
// =========================================================

export async function POST(req: NextRequest) {

  try {

    if (!supabase) {
      return NextResponse.json(
        { success: false, error: "Supabase not configured" },
        { status: 500 }
      );
    }

    const { slug } = await req.json();

    if (!slug) {
      return NextResponse.json(
        { success: false, error: "Missing slug" },
        { status: 400 }
      );
    }

    const { data: proposal, error: fetchError } = await supabase
      .from("Proposal")
      .select("*")
      .eq("slug", slug)
      .single();

    if (fetchError || !proposal) {
      return NextResponse.json(
        { success: false, error: "Proposal not found" },
        { status: 404 }
      );
    }

    const leadData = proposal.proposal_data || {};

    const ownerEmail = process.env.OWNER_NOTIFICATION_EMAIL || "info@portovenere.com";

    const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || "https://www.portovenere.com";
    const proposalUrl = `${siteUrl}/results/proposal/${encodeURIComponent(slug)}`;

    // Nessun booking ancora richiesto (confirmed_selection non esiste):
    // usiamo lo stesso set featured + esperienze incluse + enhancement
    // disponibili che generateProposal()/buildRendererData() calcolerebbero
    // per questo lead — stesso dettaglio riga-per-riga con prezzo delle
    // email post-conferma, cosi' tutte le email restano uniformi.
    const { experienceDetails, enhancementDetails, totalPrice } =
      await getAvailableLineItemsForLead({
        experiences: leadData.experiences,
        moods: leadData.moods,
        budget: leadData.budget,
        guests: leadData.guests,
        children: leadData.children,
        traveling_with_children: leadData.traveling_with_children,
        start_date: leadData.start_date,
        end_date: leadData.end_date,
      });

    const summaryData = {
      name: leadData.name || "",
      email: leadData.email || "",
      experiences: leadData.experiences || [],
      moods: leadData.moods || [],
      guests: leadData.guests || "",
      budget: leadData.budget || "",
      startDate: leadData.start_date || "",
      endDate: leadData.end_date || "",
      slug,
      experienceDetails,
      enhancementDetails,
      totalPrice,
    };

    const [ownerResult, clientResult] = await Promise.allSettled([

      sendEmail({
        to: ownerEmail,
        subject: `New proposal — ${leadData.name || "New lead"}`,
        html: ownerNewProposalTemplate(summaryData),
      }),

      leadData.email
        ? sendEmail({
            to: leadData.email,
            subject: "Your Riviera proposal is ready — Portovenere Experiences",
            html: proposalGeneratedTemplate(summaryData, proposalUrl),
          })
        : Promise.resolve({ success: false, error: "No email on file" }),

    ]);

    if (ownerResult.status === "rejected") {
      console.error("notify-new-proposal owner email failed:", ownerResult.reason);
    }

    if (clientResult.status === "rejected") {
      console.error("notify-new-proposal client email failed:", clientResult.reason);
    }

    return NextResponse.json({ success: true });

  } catch (err) {

    console.error("notify-new-proposal error:", err);

    return NextResponse.json(
      { success: false, error: "Unexpected error" },
      { status: 500 }
    );
  }
}