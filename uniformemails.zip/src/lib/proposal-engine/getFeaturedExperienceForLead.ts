import { getFullExperiences } from "@/lib/supabase/experienceRepository";
import { getEnhancements } from "@/lib/supabase/enhancementRepository";
import { generateProposal } from "@/lib/generateProposal";
import { calculatePrice } from "@/lib/pricing/calculatePrice";
import { resolveSeasonalPriceOverride } from "@/lib/pricing/resolveSeasonalPrice";
import { computeLeadPricingSnapshot, priceOrNull } from "@/lib/pricing/computeLeadPricingSnapshot";

interface LeadForProposal {
  experiences?: string[];
  moods?: string[];
  budget?: string;
  guests?: string | number;
  children?: string | number;
  traveling_with_children?: boolean;
  start_date?: string | null;
  end_date?: string | null;
}

// Forma minima usata da isIncompatible/pickCompatible — le righe reali
// (da generateProposal/getFullExperiences) portano molti altri campi,
// che qui non ci servono.
interface ExperienceLike {
  id: string;
  category?: string;
  incompatible_experiences?: string[];
  incompatible_enhancements?: string[];
}

interface EnhancementLike {
  id: string;
  active: boolean;
}

// Stesso matching di isIncompatible/pickCompatible in buildRendererData.ts —
// duplicato qui (invece che importato) perche' quello vive nel path di
// rendering della pagina, accoppiato a buildProposalGallery/buildProposalExperienceCard
// che qui non servono: a noi bastano gli id per il pricing, non le card formattate.
function isIncompatible(a: ExperienceLike | undefined, b: ExperienceLike | undefined) {
  if (!a || !b) return false;
  const aList = a.incompatible_experiences ?? [];
  const bList = b.incompatible_experiences ?? [];
  return aList.includes(b.id) || bList.includes(a.id);
}

function pickCompatible(
  pool: ExperienceLike[],
  anchor: ExperienceLike | undefined,
  max: number,
  ignoreIncompatibility = false
) {
  if (ignoreIncompatibility) return pool.slice(0, max);

  const chosen: ExperienceLike[] = [];

  for (const candidate of pool) {
    if (chosen.length >= max) break;
    if (isIncompatible(anchor, candidate)) continue;
    if (chosen.some((picked) => isIncompatible(picked, candidate))) continue;
    chosen.push(candidate);
  }

  return chosen;
}

// =====================================================================
// Estrae SOLO la featured experience che generateProposal() calcolerebbe
// per un lead — stesso identico matching usato da buildRendererData()
// per decidere cosa mostrare come esperienza principale sulla proposal
// page. Fattorizzato qui perche' serve in piu' punti (route di notifica
// email, route di traduzione) che altrimenti duplicherebbero lo stesso
// blocco di matching.
//
// Locale "en" qui non conta ai fini del matching (i campi usati —
// budget_*, guest_*, ecc. — non sono localizzati), serve solo a
// ottenere titolo/prezzo/operator in inglese per le email transazionali
// (mai tradotte, stesso trattamento di tutti gli altri template email).
// =====================================================================

async function getGeneratedProposalForLead(lead: LeadForProposal) {

  const tripDays =
    lead.start_date && lead.end_date
      ? Math.max(
          1,
          Math.round(
            (new Date(lead.end_date).getTime() -
              new Date(lead.start_date).getTime()) /
              (1000 * 60 * 60 * 24)
          ) + 1
        )
      : undefined;

  const allExperiences = await getFullExperiences("en");

  return generateProposal({
    experiencesSelected: lead.experiences || [],
    moodsSelected: lead.moods || [],
    budget: lead.budget || "",
    guests: String(lead.guests ?? ""),
    children: lead.children,
    travelingWithChildren: lead.traveling_with_children || false,
    tripDays,
    allExperiences,
  });
}

export async function getFeaturedExperienceForLead(lead: LeadForProposal) {
  const generatedProposal = await getGeneratedProposalForLead(lead);
  return generatedProposal?.featuredExperience || null;
}

// =====================================================================
// Come sopra, ma ritorna direttamente titolo+prezzo pronti per una
// email — usata sia dalla notifica "proposta generata" sia dal
// reminder automatico per chi non ha ancora cliccato "Prenota ora"
// (in entrambi i casi confirmed_selection non esiste ancora, quindi
// l'unica "selezione" reale e' la featured experience calcolata da
// generateProposal, la stessa che il cliente vede aprendo la pagina).
// =====================================================================

export async function getFeaturedExperienceLineItemForLead(
  lead: LeadForProposal
): Promise<{ title: string; price: number | null } | null> {

  const featuredExperience = await getFeaturedExperienceForLead(lead);

  if (!featuredExperience) return null;

  const seasonalPrice = resolveSeasonalPriceOverride(
    featuredExperience,
    lead.start_date
  );

  const price =
    seasonalPrice !== null
      ? Math.round(seasonalPrice)
      : priceOrNull(
          featuredExperience.pricing_type,
          calculatePrice(
            featuredExperience.base_price,
            featuredExperience.pricing_type,
            Number(lead.guests) || 1,
            Number(lead.children) || 0,
            featuredExperience.child_discount_percentage ?? 0,
            featuredExperience.price_tiers ?? [],
            featuredExperience.use_guest_tiers === true
          )
        );

  return { title: featuredExperience.title, price };
}

// =====================================================================
// Come sopra, ma ritorna l'INTERO set di esperienze/enhancement
// "disponibili" per questo lead — featured + le esperienze incluse
// (stessa selezione compatibile che buildRendererData() calcola per
// la pagina proposal, vedi pickCompatible sopra) + gli enhancement
// attivi e compatibili — non solo la featured da sola.
//
// Usata per uniformare TUTTE le email transazionali pre-conferma
// (proposta generata, reminder automatico/manuale) allo stesso
// formato dettagliato riga-per-riga con prezzo che gia' usano le
// email post-conferma (che invece leggono confirmed_selection, la
// selezione REALE fatta dal cliente sulla pagina) — richiesto perche'
// prima dell'interazione del cliente non esiste una "selezione reale",
// quindi usiamo la stessa proposta che generateProposal() calcolerebbe
// e che il cliente vedrebbe aprendo la pagina per la prima volta.
// =====================================================================

export async function getAvailableLineItemsForLead(lead: LeadForProposal): Promise<{
  experienceDetails: { title: string; price: number | null }[];
  enhancementDetails: { title: string; price: number | null }[];
  totalPrice: number | undefined;
}> {

  const generatedProposal = await getGeneratedProposalForLead(lead);
  const featuredExperience = generatedProposal?.featuredExperience;

  if (!featuredExperience) {
    return { experienceDetails: [], enhancementDetails: [], totalPrice: undefined };
  }

  const isMultiDayTrip =
    Boolean(lead.start_date) &&
    Boolean(lead.end_date) &&
    lead.start_date !== lead.end_date;

  const rankedExperiences: ExperienceLike[] = generatedProposal?.scoredExperiences || [];
  const featuredCategory = featuredExperience.category;
  const featuredId = featuredExperience.id;

  const candidatePool = rankedExperiences
    .filter((experience) => experience.id !== featuredId)
    .filter((experience) => experience.category !== featuredCategory);

  const includedExperiencesRaw = pickCompatible(candidatePool, featuredExperience, 3, isMultiDayTrip);

  const finalIncludedExperiencesRaw =
    includedExperiencesRaw.length === 0
      ? pickCompatible(generatedProposal?.suggestedAddOns || [], featuredExperience, 3, isMultiDayTrip)
      : includedExperiencesRaw;

  const experienceIds = [featuredId, ...finalIncludedExperiencesRaw.map((e) => e.id)];

  const relevantExperiences: ExperienceLike[] = [featuredExperience, ...finalIncludedExperiencesRaw].filter(
    Boolean
  );
  const incompatibleEnhancementIds = new Set<string>();

  if (!isMultiDayTrip) {
    relevantExperiences.forEach((experience) => {
      (experience.incompatible_enhancements ?? []).forEach((id) =>
        incompatibleEnhancementIds.add(String(id))
      );
    });
  }

  const allEnhancements: EnhancementLike[] = await getEnhancements("en");

  const enhancementIds = (allEnhancements || [])
    .filter((item) => item.active)
    .filter((item) => !incompatibleEnhancementIds.has(String(item.id)))
    .map((item) => item.id);

  const { lineItems } = await computeLeadPricingSnapshot({
    experienceIds,
    enhancementIds,
    guests: lead.guests ?? "",
    children: lead.children,
    checkInDate: lead.start_date,
  });

  const experienceDetails = lineItems
    .filter((item) => item.type === "experience")
    .map((item) => ({ title: item.title, price: item.price }));

  const enhancementDetails = lineItems
    .filter((item) => item.type === "enhancement")
    .map((item) => ({ title: item.title, price: item.price }));

  const totalPrice = lineItems.reduce((sum, item) => sum + (item.price ?? 0), 0);

  return { experienceDetails, enhancementDetails, totalPrice };
}
