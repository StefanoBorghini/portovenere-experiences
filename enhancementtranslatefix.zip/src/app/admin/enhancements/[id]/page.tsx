"use client";

import { useEffect, useState } from "react";
import {
  useParams,
  useRouter,
} from "next/navigation";

import { supabase } from "@/lib/supabase";

import {
  getEnhancements,
} from "@/lib/supabase/enhancementRepository";

import EnhancementCard from "./components/EnhancementCard";
import SaveBar from "../../experiences/[id]/components/SaveBar";

import {
  updateEnhancement,
  deleteEnhancement,
} from "@/lib/supabase/enhancementRepository";

export default function EnhancementEditor() {

  const params = useParams();
  const router = useRouter();

  const [enhancement,setEnhancement] =
    useState<any>(null);

  // =========================================================
  // TRADUCI ORA — sincronizza subito la traduzione italiana per
  // QUESTO enhancement, senza aspettare che compaia per caso in una
  // nuova proposal generata (l'unico momento in cui altrimenti
  // verrebbe ritradotto). Stesso bottone/pattern gia' usato nella
  // scheda esperienza (Header.tsx), idempotente per hash.
  // =========================================================

  const [translateStatus, setTranslateStatus] =
    useState<"idle" | "loading" | "done" | "error">("idle");

  async function handleTranslateNow() {

    if (!supabase || !enhancement) return;

    setTranslateStatus("loading");

    try {

      const {
        data: { session },
      } = await supabase.auth.getSession();

      const response = await fetch("/api/admin/translate-enhancement", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${session?.access_token || ""}`,
        },
        body: JSON.stringify({ enhancementId: enhancement.id }),
      });

      const data = await response.json();

      setTranslateStatus(data.success ? "done" : "error");

    } catch (err) {

      console.error("translate-enhancement failed:", err);
      setTranslateStatus("error");
    }

    setTimeout(() => setTranslateStatus("idle"), 3000);
  }

  useEffect(()=>{

    async function load(){

      const data =
        await getEnhancements();

      const found =
        data.find(
          e => e.id == params.id
        );

      setEnhancement(found);

    }

    load();

  },[params.id]);

  if(!enhancement){

    return (
      <div
        className="
          min-h-screen
          bg-black
          text-white
          flex
          items-center
          justify-center
        "
      >
        Loading...
      </div>
    );

  }

  return(

    <main
      className="
        min-h-screen
        bg-black
        text-white
        px-10
        py-12
      "
    >

      <div
        className="
          max-w-5xl
          mx-auto
        "
      >

        <div
          className="
            flex
            justify-end
            mb-6
          "
        >

          <button

            onClick={handleTranslateNow}

            disabled={translateStatus === "loading"}

            className="
              px-5
              py-3
              rounded-xl
              border
              border-white/10
              hover:bg-white/5
              transition-all
              disabled:opacity-50
              disabled:cursor-not-allowed
            "
          >

            {translateStatus === "loading"
              ? "Translating…"
              : translateStatus === "done"
              ? "Translated ✓"
              : translateStatus === "error"
              ? "Failed — retry"
              : "Translate now"}

          </button>

        </div>

        <EnhancementCard

          enhancement={enhancement}

          setEnhancement={
            setEnhancement
          }

        />

       <SaveBar

  onSave={async () => {

    const result =
      await updateEnhancement(

        enhancement.id,

        {

          title: enhancement.title,

    description: enhancement.description,

    image: enhancement.image,

    base_price: enhancement.base_price,

    price_type: enhancement.price_type,

    display_order: enhancement.display_order,

    active: enhancement.active,

    selected_button_text: enhancement.selected_button_text,

    unselected_button_text: enhancement.unselected_button_text,

        }

      );

    if(result.success){

      alert("Enhancement saved!");

    }

  }}

  onDelete={async()=>{

    const ok = confirm(
      "Delete this enhancement?"
    );

    if(!ok) return;

    const result =
      await deleteEnhancement(
        enhancement.id
      );

    if(result.success){

      router.push(
        "/admin/enhancements"
      );

    }

  }}

/>

      </div>

    </main>

  );

}