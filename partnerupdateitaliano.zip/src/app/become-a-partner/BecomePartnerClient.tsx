"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Turnstile from "react-turnstile";
import { motion, AnimatePresence } from "framer-motion";
import {
  trackPartnerPageView,
  trackPartnerStepEntered,
  trackPartnerStepBack,
  trackPartnerTypeSelected,
  trackPartnerPlanSelected,
  trackPartnerApplicationSubmitted,
  trackPartnerApplicationError,
} from "@/lib/analytics/gtag";

// =========================================================
// Wizard step-by-step, stesso linguaggio visivo e stessa
// meccanica di src/app/craft-your-experience/page.tsx (header
// con back/progress/counter, slide animation, footer back/next).
// Pagina SOLO in italiano, testo hardcoded qui direttamente —
// niente useTranslations()/site_copy: gli operatori target sono
// attivita' locali del golfo, non serve il circuito Lara. Nessun
// menu di navigazione: pagina raggiungibile solo via link diretto
// (messo su Portovenere.com, non su questo sito).
// =========================================================

const STEP_IDS = ["type", "basics", "details", "plan", "message"] as const;
type StepId = (typeof STEP_IDS)[number];

const STEP_TITLES: Record<StepId, string> = {
  type: "Che tipo di attività hai?",
  basics: "Parlaci di te",
  details: "Qualche dettaglio in più sulla tua attività",
  plan: "Quale piano ti interessa?",
  message: "C'è altro che dovremmo sapere?",
};

type Category =
  | "hotel"
  | "restaurant"
  | "private_charter"
  | "tour_operator"
  | "other";

const CATEGORY_OPTIONS: { value: Category; label: string }[] = [
  { value: "hotel", label: "Hotel / Struttura ricettiva" },
  { value: "restaurant", label: "Ristorante" },
  { value: "private_charter", label: "Noleggio privato" },
  { value: "tour_operator", label: "Tour operator" },
  { value: "other", label: "Altro" },
];

interface DetailField {
  key: string;
  label: string;
  type: "text" | "select" | "textarea";
  options?: string[];
}

const DETAIL_FIELDS: Record<Category, DetailField[]> = {
  hotel: [
    { key: "roomsCount", label: "Numero di camere", type: "select", options: ["1–10", "11–30", "31+"] },
    {
      key: "category",
      label: "Categoria",
      type: "select",
      options: ["3 stelle", "4 stelle", "5 stelle / Boutique", "B&B / Affittacamere"],
    },
    { key: "area", label: "Dove si trova la struttura?", type: "text" },
  ],
  restaurant: [
    { key: "cuisineType", label: "Che tipo di cucina proponi?", type: "text" },
    { key: "seatingCapacity", label: "Posti a sedere", type: "select", options: ["Fino a 30", "30–60", "60+"] },
    {
      key: "priceRange",
      label: "Fascia di prezzo",
      type: "select",
      options: ["€ Informale", "€€ Fascia media", "€€€ Alta cucina"],
    },
  ],
  private_charter: [
    { key: "fleetType", label: "Che imbarcazioni gestisci?", type: "text" },
    { key: "maxGuests", label: "Ospiti massimi", type: "select", options: ["Fino a 6", "7–12", "13+"] },
    {
      key: "skipperIncluded",
      label: "Skipper incluso?",
      type: "select",
      options: ["Sì, sempre", "Facoltativo", "No, solo noleggio"],
    },
  ],
  tour_operator: [
    { key: "tourTypes", label: "Che tipo di tour proponi?", type: "text" },
    {
      key: "groupSize",
      label: "Dimensione tipica del gruppo",
      type: "select",
      options: ["Privato / piccolo gruppo (1–8)", "Gruppo medio (9–20)", "Gruppo grande (20+)"],
    },
    { key: "languages", label: "Che lingue offri?", type: "text" },
  ],
  other: [{ key: "description", label: "Raccontaci della tua attività", type: "textarea" }],
};

interface PlanOption {
  value: "base" | "premium" | "signature" | "not_sure";
  name?: string;
  price?: string;
  tagline?: string;
  label?: string;
}

const PLAN_OPTIONS: PlanOption[] = [
  { value: "base", name: "Base", price: "€120 / anno", tagline: "Per chi vuole esserci." },
  { value: "premium", name: "Premium", price: "€180 / anno", tagline: "Per chi vuole essere promosso." },
  {
    value: "signature",
    name: "Signature",
    price: "Su richiesta",
    tagline: "Solo su candidatura — un'esperienza in evidenza nel configuratore.",
  },
  { value: "not_sure", label: "Non sono sicuro/a" },
];

const slideVariants = {
  enter: (direction: number) => ({
    x: direction > 0 ? 80 : -80,
    opacity: 0,
  }),
  center: {
    x: 0,
    opacity: 1,
  },
  exit: (direction: number) => ({
    x: direction > 0 ? -80 : 80,
    opacity: 0,
  }),
};

const inputClass =
  "w-full rounded-2xl px-6 py-3.5 text-white placeholder:text-zinc-500 outline-none border border-white/10 bg-white/5 focus:border-white/40 transition";

export default function BecomePartnerClient() {
  const router = useRouter();

  const [currentStep, setCurrentStep] = useState(0);
  const [direction, setDirection] = useState(0);

  const [category, setCategory] = useState<Category | null>(null);
  const [companyName, setCompanyName] = useState("");
  const [contactName, setContactName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [website, setWebsite] = useState("");
  const [instagram, setInstagram] = useState("");
  const [details, setDetails] = useState<Record<string, string>>({});
  const [planInterest, setPlanInterest] = useState<PlanOption["value"]>("not_sure");
  const [message, setMessage] = useState("");
  const [captchaToken, setCaptchaToken] = useState("");
  const [status, setStatus] = useState<"idle" | "sending" | "success" | "error">("idle");

  const stepId: StepId = STEP_IDS[currentStep];
  const totalSteps = STEP_IDS.length;
  const progressPercent = ((currentStep + 1) / totalSteps) * 100;

  useEffect(() => {
    trackPartnerPageView();
  }, []);

  useEffect(() => {
    trackPartnerStepEntered(stepId, currentStep);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentStep]);

  function setDetailField(key: string, value: string) {
    setDetails((prev) => ({ ...prev, [key]: value }));
  }

  function isStepValid(step: StepId): boolean {
    switch (step) {
      case "type":
        return category !== null;
      case "basics":
        return (
          !!companyName.trim() &&
          !!contactName.trim() &&
          /\S+@\S+\.\S+/.test(email)
        );
      case "details": {
        if (!category) return false;
        return DETAIL_FIELDS[category].every((f) => !!details[f.key]?.trim());
      }
      case "plan":
        return true;
      case "message":
        return !!captchaToken;
      default:
        return true;
    }
  }

  const currentStepValid = isStepValid(stepId);

  function goNext() {
    if (!currentStepValid) return;

    if (stepId === "message") {
      handleSubmit();
      return;
    }

    setDirection(1);
    setCurrentStep((s) => s + 1);
  }

  function goBack() {
    if (currentStep === 0) {
      router.push("/");
      return;
    }
    trackPartnerStepBack(stepId, currentStep);
    setDirection(-1);
    setCurrentStep((s) => s - 1);
  }

  async function handleSubmit() {
    if (!category) return;

    setStatus("sending");

    try {

      const response = await fetch("/api/partner-application", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          turnstileToken: captchaToken,
          companyName,
          contactName,
          email,
          phone,
          category,
          details,
          planInterest,
          website,
          instagram,
          message,
          locale: "it",
        }),
      });

      const data = await response.json();

      if (!data.success) {
        setStatus("error");
        trackPartnerApplicationError(data.error || "unknown");
        return;
      }

      setStatus("success");
      trackPartnerApplicationSubmitted(planInterest, category);

    } catch (err) {
      console.error("partner-application submit failed:", err);
      setStatus("error");
      trackPartnerApplicationError("network");
    }
  }

  function selectCategory(value: Category) {
    setCategory(value);
    setDetails({});
    trackPartnerTypeSelected(value);
  }

  function selectPlan(plan: PlanOption["value"]) {
    setPlanInterest(plan);
    if (plan !== "not_sure") trackPartnerPlanSelected(plan);
  }

  // =======================================================
  // SUCCESS
  // =======================================================

  if (status === "success") {
    return (
      <main className="h-dvh flex items-center justify-center bg-[#0C0C0C] text-white px-6 text-center">
        <p className="text-xl md:text-2xl font-light max-w-md leading-relaxed">
          Grazie — abbiamo ricevuto la tua candidatura e ti ricontatteremo
          personalmente a breve.
        </p>
      </main>
    );
  }

  // =======================================================
  // STEP CONTENT
  // =======================================================

  function renderStep() {
    switch (stepId) {

      case "type":
        return (
          <div className="grid gap-3">
            {CATEGORY_OPTIONS.map(({ value, label }) => (
              <button
                type="button"
                key={value}
                onClick={() => selectCategory(value)}
                className={`min-w-0 border rounded-2xl px-6 py-5 text-left transition-all duration-500 ease-out ${
                  category === value
                    ? "border-white bg-white text-black"
                    : "border-white/10 bg-white/5 hover:border-white/40"
                }`}
              >
                <span className="block text-base font-light break-words">{label}</span>
              </button>
            ))}
          </div>
        );

      case "basics":
        return (
          <div className="space-y-5">
            <TextField label="Nome dell'attività" value={companyName} onChange={setCompanyName} />
            <TextField label="Il tuo nome" value={contactName} onChange={setContactName} />
            <TextField label="Email" value={email} onChange={setEmail} type="email" />
            <TextField label="Telefono (facoltativo)" value={phone} onChange={setPhone} type="tel" />
            <TextField label="Sito web (facoltativo)" value={website} onChange={setWebsite} type="url" />
            <TextField label="Instagram (facoltativo)" value={instagram} onChange={setInstagram} />
          </div>
        );

      case "details": {
        if (!category) return null;

        const fields = DETAIL_FIELDS[category];

        return (
          <div className="space-y-5">
            {fields.map((field) => {

              if (field.type === "text") {
                return (
                  <TextField
                    key={field.key}
                    label={field.label}
                    value={details[field.key] || ""}
                    onChange={(v) => setDetailField(field.key, v)}
                  />
                );
              }

              if (field.type === "textarea") {
                return (
                  <div key={field.key}>
                    <p className="uppercase tracking-[0.3em] text-zinc-500 text-sm mb-2">
                      {field.label}
                    </p>
                    <textarea
                      value={details[field.key] || ""}
                      onChange={(e) => setDetailField(field.key, e.target.value)}
                      rows={4}
                      className={inputClass}
                    />
                  </div>
                );
              }

              return (
                <div key={field.key}>
                  <p className="uppercase tracking-[0.3em] text-zinc-500 text-sm mb-2">
                    {field.label}
                  </p>
                  <div className="grid gap-2.5">
                    {(field.options || []).map((option) => (
                      <button
                        type="button"
                        key={option}
                        onClick={() => setDetailField(field.key, option)}
                        className={`min-w-0 border rounded-2xl px-5 py-3 text-left text-sm break-words transition-all duration-500 ease-out ${
                          details[field.key] === option
                            ? "border-white bg-white text-black"
                            : "border-white/10 bg-white/5 hover:border-white/40"
                        }`}
                      >
                        {option}
                      </button>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        );
      }

      case "plan":
        return (
          <div className="grid gap-3">
            {PLAN_OPTIONS.map((plan) => (
              <button
                type="button"
                key={plan.value}
                onClick={() => selectPlan(plan.value)}
                className={`min-w-0 border rounded-2xl px-6 py-5 text-left transition-all duration-500 ease-out ${
                  planInterest === plan.value
                    ? "border-white bg-white text-black"
                    : "border-white/10 bg-white/5 hover:border-white/40"
                }`}
              >
                {plan.value === "not_sure" ? (
                  <span className="block text-base font-light break-words">{plan.label}</span>
                ) : (
                  <>
                    <div className="flex items-baseline justify-between gap-2 flex-wrap">
                      <span className="min-w-0 break-words text-base font-light">{plan.name}</span>
                      <span
                        className={`min-w-0 break-words text-sm ${
                          planInterest === plan.value ? "text-black/60" : "text-zinc-500"
                        }`}
                      >
                        {plan.price}
                      </span>
                    </div>
                    <span
                      className={`block text-sm mt-1 break-words ${
                        planInterest === plan.value ? "text-black/60" : "text-zinc-500"
                      }`}
                    >
                      {plan.tagline}
                    </span>
                  </>
                )}
              </button>
            ))}
          </div>
        );

      case "message":
        return (
          <div className="space-y-6">
            <textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Messaggio facoltativo"
              rows={5}
              className={inputClass}
            />

            <div className="flex justify-center">
              <Turnstile
                sitekey={process.env.NEXT_PUBLIC_TURNSTILE_SITE_KEY!}
                onVerify={(token) => setCaptchaToken(token)}
              />
            </div>

            {status === "error" && (
              <p className="text-center text-red-400 text-sm">
                Qualcosa è andato storto — riprova, oppure scrivici direttamente su WhatsApp.
              </p>
            )}
          </div>
        );

      default:
        return null;
    }
  }

  // =======================================================
  // SHELL
  // =======================================================

  return (
    <main className="h-dvh overflow-hidden bg-[#0C0C0C] text-white flex flex-col break-words">

      {/* HEADER: back + progress + counter — compatto, altezza fissa */}
      <div className="px-6 pt-4 pb-2 md:pt-6 md:pb-3 max-w-xl w-full mx-auto shrink-0">

        <div className="flex items-center gap-4 mb-2 md:mb-4">

          <button
            type="button"
            onClick={goBack}
            aria-label="Indietro"
            className="text-2xl opacity-70 hover:opacity-100 transition-opacity"
          >
            &#8592;
          </button>

          <div className="flex-1 h-[2px] bg-white/10 rounded-full overflow-hidden">
            <div
              className="h-full bg-[#d6c6a5] transition-all duration-500 ease-out"
              style={{ width: `${progressPercent}%` }}
            />
          </div>

          <p className="text-xs text-zinc-500 tabular-nums">
            {currentStep + 1} / {totalSteps}
          </p>

        </div>

        <p className="uppercase tracking-[0.3em] text-zinc-500 text-xs mb-2">
          Portovenere Experience — Per gli operatori
        </p>

        <h1 className="text-xl md:text-4xl font-light leading-tight">
          {STEP_TITLES[stepId]}
        </h1>

      </div>

      <div className="flex-1 min-h-0 flex flex-col justify-between gap-3 md:gap-6 overflow-y-auto pt-4 pb-4 md:pb-6 px-6 max-w-xl w-full mx-auto">

        <AnimatePresence mode="wait" custom={direction}>
          <motion.div
            key={currentStep}
            custom={direction}
            variants={slideVariants}
            initial="enter"
            animate="center"
            exit="exit"
            transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
          >
            {renderStep()}
          </motion.div>
        </AnimatePresence>

        <div className="flex gap-4 shrink-0">

          <button
            type="button"
            onClick={goBack}
            className="w-1/3 rounded-full px-2 py-3.5 uppercase tracking-[0.25em] text-xs border border-white/20 text-white/70 hover:border-white/40 hover:text-white transition-all duration-500"
          >
            Indietro
          </button>

          <button
            type="button"
            onClick={goNext}
            disabled={!currentStepValid || status === "sending"}
            className={`w-2/3 rounded-full px-4 py-3.5 uppercase tracking-[0.2em] text-[11px] leading-snug text-center transition-all duration-500 ${
              currentStepValid && status !== "sending"
                ? "bg-white text-black hover:scale-[1.02]"
                : "bg-white/10 text-white/30 cursor-not-allowed"
            }`}
          >
            {stepId === "message"
              ? status === "sending"
                ? "Invio in corso..."
                : "Invia candidatura"
              : "Avanti"}
          </button>

        </div>
      </div>
    </main>
  );
}

function TextField({
  label,
  value,
  onChange,
  type = "text",
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  type?: string;
}) {
  return (
    <div>
      <p className="uppercase tracking-[0.3em] text-zinc-500 text-sm mb-2">
        {label}
      </p>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className={inputClass}
      />
    </div>
  );
}
