import { NextRequest, NextResponse } from "next/server";
import { supabase } from "@/lib/supabase";
import { getSupabaseAdmin } from "@/lib/supabase/adminClient";
import { getStripe, getDepositPercentage } from "@/lib/stripe/stripeClient";
import { computeLeadPricingSnapshot } from "@/lib/pricing/computeLeadPricingSnapshot";
import { sendEmail } from "@/lib/email/sendEmail";
import { depositPaymentRequestedTemplate } from "@/lib/email/templates";

// =========================================================
// POST /api/admin/request-payment
// Bottone "Request Payment" nella scheda lead in admin — SOLO azione
// che fa avanzare payment_status oltre 'none' (mai automatico su
// "Prenota Ora": decisione di prodotto, il team rivede disponibilita'
// prima di chiedere il pagamento).
//
// Split multi-operatore: l'acconto viene addebitato sul conto Stripe
// di Portovenere (unico modo Stripe per un pagamento che deve poi
// dividersi su piu' account Connect diversi), poi lo split calcolato
// qui viene ESEGUITO dal webhook (checkout.session.completed) come
// Transfer separati verso ciascun operatore coinvolto — vedi
// src/app/api/webhooks/stripe/route.ts. Lo split va bloccato ORA,
// non ricalcolato al momento del webhook: deve corrispondere esattamente
// a quanto e' stato davvero addebitato in questo preciso momento.
// =========================================================

export async function POST(req: NextRequest) {

  try {

    if (!supabase) {
      return NextResponse.json({ success: false, error: "Supabase not configured" }, { status: 500 });
    }

    const authHeader = req.headers.get("authorization");
    const accessToken = authHeader?.replace("Bearer ", "");

    if (!accessToken) {
      return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
    }

    const { data: userData, error: authError } = await supabase.auth.getUser(accessToken);

    if (authError || !userData?.user) {
      return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
    }

    const { leadId } = await req.json();

    if (!leadId) {
      return NextResponse.json({ success: false, error: "Missing leadId" }, { status: 400 });
    }

    const supabaseAdmin = getSupabaseAdmin();

    const { data: proposal, error: fetchError } = await supabaseAdmin
      .from("Proposal")
      .select("*")
      .eq("lead_id", leadId)
      .single();

    if (fetchError || !proposal) {
      return NextResponse.json({ success: false, error: "No proposal found for this lead" }, { status: 404 });
    }

    if (!proposal.email_verified) {
      return NextResponse.json(
        { success: false, error: "Client hasn't confirmed their email yet — send/wait for confirmation first" },
        { status: 400 }
      );
    }

    if (proposal.payment_status === "deposit_paid") {
      return NextResponse.json(
        { success: false, error: "Deposit already paid for this proposal" },
        { status: 400 }
      );
    }

    const experienceIds: string[] = proposal.confirmed_selection?.experienceIds || [];
    const enhancementIds: string[] = proposal.confirmed_selection?.enhancementIds || [];

    if (experienceIds.length === 0 && enhancementIds.length === 0) {
      return NextResponse.json(
        { success: false, error: "No confirmed selection to charge" },
        { status: 400 }
      );
    }

    const leadData = proposal.proposal_data || {};

    const { finalPrice, lineItems } = await computeLeadPricingSnapshot({
      experienceIds,
      enhancementIds,
      guests: leadData.guests,
      children: leadData.children,
      checkInDate: leadData.start_date,
    });

    if (finalPrice <= 0) {
      return NextResponse.json(
        { success: false, error: "Nothing priced to charge (all items are on request)" },
        { status: 400 }
      );
    }

    // ---------------------------------------------------------
    // Ogni riga con un prezzo reale deve avere un operatore Stripe
    // attivo — la gating del configuratore (getBookableExperiences/
    // getBookableEnhancements) dovrebbe gia' garantirlo, ma un
    // operatore potrebbe essersi disconnesso DOPO che il cliente ha
    // confermato la selezione: qui e' l'ultimo punto in cui possiamo
    // ancora bloccare in sicurezza, prima di addebitare soldi veri.
    // ---------------------------------------------------------

    const pricedItems = lineItems.filter((item) => item.price !== null && item.price > 0);
    const operatorIds = Array.from(
      new Set(pricedItems.map((item) => item.operator_id).filter((id): id is string => Boolean(id)))
    );

    if (operatorIds.length === 0 || operatorIds.length !== new Set(pricedItems.map((i) => i.operator_id)).size) {
      return NextResponse.json(
        { success: false, error: "One or more priced items have no assigned operator" },
        { status: 400 }
      );
    }

    const { data: operators, error: operatorsError } = await supabaseAdmin
      .from("operators")
      .select("id, stripe_account_id, stripe_onboarding_status")
      .in("id", operatorIds);

    if (operatorsError) {
      console.error("request-payment: error loading operators", operatorsError);
      return NextResponse.json({ success: false, error: "Could not load operators" }, { status: 500 });
    }

    const operatorsById = new Map((operators || []).map((op) => [op.id, op]));

    const notReady = operatorIds.filter((id) => {
      const op = operatorsById.get(id);
      return !op || op.stripe_onboarding_status !== "active" || !op.stripe_account_id;
    });

    if (notReady.length > 0) {
      return NextResponse.json(
        {
          success: false,
          error: "One or more operators in this proposal are no longer connected to Stripe — reassign or wait for onboarding.",
        },
        { status: 400 }
      );
    }

    // ---------------------------------------------------------
    // ACCONTO + SPLIT — in centesimi (Stripe vuole l'unita' minima
    // della valuta). L'arrotondamento per riga puo' lasciare un
    // piccolo residuo che semplicemente resta a Portovenere (mai
    // ai singoli operatori un centesimo in piu' di quanto calcolato).
    // ---------------------------------------------------------

    const depositPercentage = getDepositPercentage();
    const depositAmountEuros = Math.round((finalPrice * depositPercentage) / 100);
    const depositAmountCents = depositAmountEuros * 100;

    const totalsByOperator = new Map<string, number>();

    pricedItems.forEach((item) => {
      const operatorId = item.operator_id as string;
      totalsByOperator.set(operatorId, (totalsByOperator.get(operatorId) || 0) + (item.price || 0));
    });

    const depositSplit = Array.from(totalsByOperator.entries()).map(([operatorId, operatorTotal]) => {
      const operator = operatorsById.get(operatorId)!;
      const amountCents = Math.floor((depositAmountCents * operatorTotal) / finalPrice);
      return {
        operatorId,
        stripeAccountId: operator.stripe_account_id as string,
        amount: amountCents,
      };
    });

    // ---------------------------------------------------------
    // STRIPE CHECKOUT SESSION — sul conto piattaforma (vedi commento
    // in testa al file). Il webhook legge deposit_split da Proposal
    // per creare i Transfer dopo il pagamento riuscito.
    // ---------------------------------------------------------

    const stripe = getStripe();
    const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || "https://experiences.portovenere.com";

    const session = await stripe.checkout.sessions.create({
      mode: "payment",
      payment_method_types: ["card"],
      customer_email: leadData.email || undefined,
      line_items: [
        {
          price_data: {
            currency: "eur",
            product_data: {
              name: "Portovenere Experience — Booking deposit",
            },
            unit_amount: depositAmountCents,
          },
          quantity: 1,
        },
      ],
      success_url: `${siteUrl}/results/proposal/${proposal.slug}?payment=success`,
      cancel_url: `${siteUrl}/results/proposal/${proposal.slug}?payment=cancelled`,
      metadata: {
        proposalSlug: proposal.slug,
        leadId: String(leadId),
      },
    });

    const { error: updateError } = await supabaseAdmin
      .from("Proposal")
      .update({
        payment_status: "payment_requested",
        deposit_amount: depositAmountEuros,
        stripe_checkout_session_id: session.id,
        deposit_split: depositSplit,
      })
      .eq("lead_id", leadId);

    if (updateError) {
      console.error("request-payment: update error", updateError);
      return NextResponse.json({ success: false, error: "Could not save payment request" }, { status: 500 });
    }

    if (leadData.email && session.url) {
      const emailResult = await sendEmail({
        to: leadData.email,
        subject: "Complete your booking — Portovenere Experiences",
        html: depositPaymentRequestedTemplate(
          {
            name: leadData.name || "",
            email: leadData.email || "",
            experiences: leadData.experiences || [],
            moods: leadData.moods || [],
            guests: leadData.guests || "",
            budget: leadData.budget || "",
            startDate: leadData.start_date || "",
            endDate: leadData.end_date || "",
            slug: proposal.slug,
            experienceDetails: lineItems
              .filter((item) => item.type === "experience")
              .map((item) => ({ title: item.title, price: item.price })),
            enhancementDetails: lineItems
              .filter((item) => item.type === "enhancement")
              .map((item) => ({ title: item.title, price: item.price })),
            totalPrice: finalPrice,
          },
          session.url,
          depositAmountEuros
        ),
      });

      if (!emailResult.success) {
        console.error("request-payment: email failed to send", emailResult.error);
      }
    }

    return NextResponse.json({ success: true, depositAmount: depositAmountEuros, checkoutUrl: session.url });

  } catch (err) {

    console.error("admin/request-payment error:", err);

    return NextResponse.json({ success: false, error: "Unexpected error" }, { status: 500 });
  }
}
