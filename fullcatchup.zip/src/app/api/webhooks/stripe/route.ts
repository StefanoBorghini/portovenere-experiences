import { NextRequest, NextResponse } from "next/server";
import Stripe from "stripe";
import { getSupabaseAdmin } from "@/lib/supabase/adminClient";
import { getStripe } from "@/lib/stripe/stripeClient";
import { sendEmail } from "@/lib/email/sendEmail";
import { depositPaidClientTemplate, ownerDepositPaidTemplate } from "@/lib/email/templates";

// =========================================================
// POST /api/webhooks/stripe
// Unico punto in cui i Transfer verso gli operatori vengono creati —
// MAI nella route che genera il Checkout Session (/api/admin/request-payment),
// perche' li' il pagamento non e' ancora avvenuto. Il piano di split
// (Proposal.deposit_split) e' gia' bloccato da quella route: qui lo
// eseguiamo cosi' com'e', senza ricalcolare nulla.
//
// Verifica firma OBBLIGATORIA (constructEvent): senza, chiunque
// potrebbe chiamare questa route con un payload finto e far scattare
// Transfer di denaro reale verso account Stripe arbitrari.
// =========================================================

export async function POST(req: NextRequest) {

  const signature = req.headers.get("stripe-signature");
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;

  if (!signature || !webhookSecret) {
    return NextResponse.json({ error: "Missing signature or webhook secret" }, { status: 400 });
  }

  const rawBody = await req.text();
  const stripe = getStripe();

  let event: Stripe.Event;

  try {
    event = stripe.webhooks.constructEvent(rawBody, signature, webhookSecret);
  } catch (err) {
    console.error("stripe webhook: signature verification failed", err);
    return NextResponse.json({ error: "Invalid signature" }, { status: 400 });
  }

  const supabaseAdmin = getSupabaseAdmin();

  try {

    switch (event.type) {

      case "checkout.session.completed": {

        const session = event.data.object as Stripe.Checkout.Session;
        const leadId = session.metadata?.leadId;

        if (!leadId) {
          console.error("stripe webhook: checkout.session.completed missing leadId metadata");
          break;
        }

        const { data: proposal, error: fetchError } = await supabaseAdmin
          .from("Proposal")
          .select("*")
          .eq("lead_id", leadId)
          .single();

        if (fetchError || !proposal) {
          console.error("stripe webhook: proposal not found for leadId", leadId);
          break;
        }

        // Idempotenza — Stripe puo' rimandare lo stesso evento piu'
        // volte: se il deposito e' gia' segnato pagato, non ricreare
        // i Transfer una seconda volta.
        if (proposal.payment_status === "deposit_paid") {
          break;
        }

        const depositSplit: { operatorId: string; stripeAccountId: string; amount: number }[] =
          proposal.deposit_split || [];

        // source_transaction lega il Transfer al pagamento originale,
        // garantendo che i fondi siano davvero disponibili — serve
        // l'id del charge, non della session.
        const paymentIntentId =
          typeof session.payment_intent === "string" ? session.payment_intent : session.payment_intent?.id;

        let chargeId: string | undefined;

        if (paymentIntentId) {
          const paymentIntent = await stripe.paymentIntents.retrieve(paymentIntentId);
          chargeId =
            typeof paymentIntent.latest_charge === "string"
              ? paymentIntent.latest_charge
              : paymentIntent.latest_charge?.id;
        }

        const { data: operators } = await supabaseAdmin
          .from("operators")
          .select("id, name")
          .in("id", depositSplit.map((row) => row.operatorId));

        const operatorNameById = new Map((operators || []).map((op) => [op.id, op.name]));

        const splitResults: { operatorName: string; amount: number; transferStatus: "ok" | "failed" }[] = [];

        for (const row of depositSplit) {

          if (row.amount <= 0) continue;

          try {
            await stripe.transfers.create({
              amount: row.amount,
              currency: "eur",
              destination: row.stripeAccountId,
              source_transaction: chargeId,
              transfer_group: session.id,
            });

            splitResults.push({
              operatorName: operatorNameById.get(row.operatorId) || row.operatorId,
              amount: row.amount / 100,
              transferStatus: "ok",
            });
          } catch (transferErr) {
            // Un transfer fallito non deve bloccare gli altri, ne'
            // impedire di segnare il deposito come pagato (il cliente
            // ha comunque pagato) — ma DEVE arrivare all'owner, non
            // sparire in silenzio: vedi ownerDepositPaidTemplate.
            console.error(`stripe webhook: transfer to ${row.stripeAccountId} failed`, transferErr);

            splitResults.push({
              operatorName: operatorNameById.get(row.operatorId) || row.operatorId,
              amount: row.amount / 100,
              transferStatus: "failed",
            });
          }
        }

        await supabaseAdmin
          .from("Proposal")
          .update({
            payment_status: "deposit_paid",
            paid_at: new Date().toISOString(),
            stripe_payment_intent_id: paymentIntentId || null,
          })
          .eq("lead_id", leadId);

        const leadData = proposal.proposal_data || {};
        const depositAmount = Number(proposal.deposit_amount || 0);

        const summaryData = {
          name: leadData.name || "",
          email: leadData.email || "",
          experiences: leadData.experiences || [],
          moods: leadData.moods || [],
          guests: leadData.guests || "",
          budget: leadData.budget || "",
          startDate: leadData.start_date || "",
          endDate: leadData.end_date || "",
          slug: proposal.slug,
          experienceDetails: proposal.confirmed_selection?.experienceDetails || [],
          enhancementDetails: proposal.confirmed_selection?.enhancementDetails || [],
          totalPrice: proposal.total_price || 0,
        };

        const ownerEmail = process.env.OWNER_NOTIFICATION_EMAIL || "info@portovenere.com";

        await Promise.allSettled([
          leadData.email
            ? sendEmail({
                to: leadData.email,
                subject: "Your deposit has been received — Portovenere Experiences",
                html: depositPaidClientTemplate(summaryData, depositAmount),
              })
            : Promise.resolve(),

          sendEmail({
            to: ownerEmail,
            subject: `Deposit paid — ${leadData.name || "Client"}`,
            html: ownerDepositPaidTemplate(summaryData, depositAmount, splitResults),
          }),
        ]);

        break;
      }

      case "checkout.session.expired": {

        const session = event.data.object as Stripe.Checkout.Session;
        const leadId = session.metadata?.leadId;

        if (leadId) {
          await supabaseAdmin
            .from("Proposal")
            .update({ payment_status: "failed" })
            .eq("lead_id", leadId)
            .eq("payment_status", "payment_requested");
        }

        break;
      }

      case "account.updated": {

        const account = event.data.object as Stripe.Account;

        const status =
          account.charges_enabled && account.payouts_enabled ? "active" : "pending";

        await supabaseAdmin
          .from("operators")
          .update({ stripe_onboarding_status: status })
          .eq("stripe_account_id", account.id);

        break;
      }

      default:
        break;
    }

    return NextResponse.json({ received: true });

  } catch (err) {

    console.error("stripe webhook: unexpected error", err);

    return NextResponse.json({ error: "Unexpected error" }, { status: 500 });
  }
}
